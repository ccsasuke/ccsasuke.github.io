# Financial Table Dataset
This dataset contains annotation of the semantics of 72 financial tables, comprising the 2015 Q3 financial statements of 6 companies:
 - Air Canada (6 tables)
 - Cogeco (9 tables)
 - Rogers (20 tables)
 - Telus (21 tables)
 - Transat (8 tables) 
 - Westjet(8 tables)

If you use this dataset, please cite the following paper:

A Rectangle Mining Method for Understanding the Semantics of Financial Tables 
Xilun Chen, Laura Chiticariu, Marina Danilevsky, Alexandre Evfimievski and Prithviraj Sen 
International Conference on Document Analysis and Recognition (ICDAR), 2017

## Folder Structure
- /pdfs/: contains the original tables in PDF format.
- /htmls/: contains tables in the automatically converted and manually corrected HTML format for machine readability.
- /annotations/: contains the row semantic annotation in CSV format.
